package com.TrainBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}

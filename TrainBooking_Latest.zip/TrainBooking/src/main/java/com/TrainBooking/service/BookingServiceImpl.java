package com.TrainBooking.service;

import com.TrainBooking.dto.response.BookingResponse;
import com.TrainBooking.model.Booking;
import com.TrainBooking.model.Train;
import com.TrainBooking.model.User;
import com.TrainBooking.repository.BookingRepository;
import com.TrainBooking.repository.TrainRepository;
import com.TrainBooking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookingServiceImpl implements BookingService{

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private TrainRepository trainRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<BookingResponse> getBookings(Long userId) {
        User user = new User();
        user.setId(userId);
        List<Booking> bookings = bookingRepository.findAllByUser(user);
        if(bookings != null) {
            List<BookingResponse> bookingResponses = bookings.stream().map(booking -> {
                BookingResponse response = new BookingResponse();
                response.setBookingId(booking.getId());
                response.setDest(booking.getTrain().getDestCity());
                response.setSource(booking.getTrain().getSourceCity());
                response.setPrice(booking.getPrice());
                response.setTrainName(booking.getTrain().getTrainName());
                response.setBookingDate(String.valueOf(booking.getBookingDate()));
                if(response.getBookingDate() == null) {
                    response.setBookingDate("NA");
                }

                return response;
            }).collect(Collectors.toList());

            return bookingResponses;
        } else {
            return null;
        }
    }

    @Override
    public void bookTrain(Long userId, Long trainId) {

        Optional<User> user = userRepository.findById(userId);
        Optional<Train> train = trainRepository.findById(trainId);

        if(user.isPresent() && train.isPresent()) {
            Booking booking = new Booking();
            booking.setTrain(train.get());
            booking.setUser(user.get());
            booking.setPrice(train.get().getPrice());
            booking.setBookingDate(LocalDateTime.now());
            bookingRepository.save(booking);
        }
    }
}

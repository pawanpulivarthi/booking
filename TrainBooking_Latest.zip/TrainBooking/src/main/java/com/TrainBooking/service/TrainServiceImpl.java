package com.TrainBooking.service;

import com.TrainBooking.model.Train;
import com.TrainBooking.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TrainServiceImpl implements TrainService{

    @Autowired
    private TrainRepository trainRepository;

    @Override
    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    @Override
    public List<Train> getAllTrains(String source, String dest) {
        return getAllTrains().stream().filter(train -> train.getSourceCity().equalsIgnoreCase(source) && train.getDestCity().equalsIgnoreCase(dest)).collect(Collectors.toList());
    }
}

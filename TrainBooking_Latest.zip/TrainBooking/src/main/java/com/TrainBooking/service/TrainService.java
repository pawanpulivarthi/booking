package com.TrainBooking.service;

import com.TrainBooking.model.Train;

import java.util.List;

public interface TrainService {

    List<Train> getAllTrains();

    List<Train> getAllTrains(String source, String dest);
}

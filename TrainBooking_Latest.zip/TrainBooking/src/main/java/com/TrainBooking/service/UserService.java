package com.TrainBooking.service;

import com.TrainBooking.model.User;

public interface UserService {

    User findByUsername(String username);

    User userLogin(User user);
}

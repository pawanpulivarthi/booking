package com.TrainBooking.service;

import com.TrainBooking.dto.response.BookingResponse;

import java.util.List;

public interface BookingService {

    List<BookingResponse> getBookings(Long userId);

    void bookTrain(Long userId, Long trainId);
}

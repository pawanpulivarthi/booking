package com.TrainBooking.controller;

import com.TrainBooking.dto.request.SearchRequest;
import com.TrainBooking.model.Train;
import com.TrainBooking.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TrainController {

    @Autowired
    private TrainService trainService;

    @GetMapping("/api/search-trains")
    public ResponseEntity<List<Train>> search(@RequestParam("source") String source, @RequestParam("dest") String destination) {
        List<Train> trains = trainService.getAllTrains(source, destination);
        return ResponseEntity.ok(trains);
    }
}

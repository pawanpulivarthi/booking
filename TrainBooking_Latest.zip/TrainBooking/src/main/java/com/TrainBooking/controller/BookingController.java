package com.TrainBooking.controller;

import com.TrainBooking.dto.response.BookingResponse;
import com.TrainBooking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @RequestMapping(value = "/api/booking-history", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<BookingResponse>> getBookings(@RequestParam("userId") Long userId) {

        List<BookingResponse> bookingResponses = bookingService.getBookings(userId);

        return ResponseEntity.ok().body(bookingResponses);
    }

    @RequestMapping(value = "/api/book-train", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> bookTrain(@RequestParam("trainId") Long trainId, @RequestParam("userId") Long userId) {

        bookingService.bookTrain(userId, trainId);

        return ResponseEntity.ok().body("Booking is completed.");
    }
}

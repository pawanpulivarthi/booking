package com.TrainBooking.controller;

import com.TrainBooking.dto.request.SearchRequest;
import com.TrainBooking.model.User;
import com.TrainBooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public String login(Model model, User user) {

        User existingUser = userService.userLogin(user);

        if(existingUser == null) {
            model.addAttribute("msg", "User doesn't exist");
            return "login";
        } else{
            model.addAttribute("user", existingUser);
            model.addAttribute("searchRequest", new SearchRequest());
            return "user-home";
        }
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }
}
